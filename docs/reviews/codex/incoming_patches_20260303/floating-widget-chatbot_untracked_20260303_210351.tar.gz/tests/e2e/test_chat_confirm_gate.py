import json
import time
from pathlib import Path

import pytest
from playwright.sync_api import Page, expect

# this test does not need the full server; we'll load the widget HTML and JS inline


def test_chat_confirm_gate(page: Page):
    # dump console messages to assist debugging
    page.on("console", lambda msg: print("PAGE_LOG:", msg.text))
    """Validate that the chatbot confirm UI requires an explicit action selection
    and that the confirm POST contains the chosen action_id.
    """
    # load widget HTML and JS inline so we don't depend on server
    # root is project workspace (two levels up from tests/e2e)
    root = Path(__file__).parent.parent.parent
    chatbot_html = (root / "app/templates/partials/floating_chat.html").read_text()
    chatbot_js = (root / "app/static/js/chatbot.js").read_text()
    # append test hooks to JS so we can call ask() directly and inspect confirm state
    chatbot_js += "\nwindow.__test_ask = ask;\nwindow.__isConfirmHidden = () => document.getElementById('floating-chat-confirm').hidden;\n"
    page.set_content(f"""
<!doctype html><html><head><meta charset='utf-8'></head><body>
{chatbot_html}
<script>{chatbot_js}</script>
</body></html>
""")
    # widget should initialize automatically; wait for toggle
    page.wait_for_selector('#floating-chat-toggle', state='visible')
    page.click('#floating-chat-toggle')

    # prepare to intercept the first API call and respond with a confirm proposal
    proposal = {
        'ok': True,
        'requires_confirm': True,
        'confirm_prompt': 'Bitte wählen',
        'pending_id': 'xyz123',
        'actions': [
            {'id': 'act1', 'label': 'Action One'},
            {'id': 'act2', 'label': 'Action Two'},
        ],
    }

    # store payload of confirm request for assertion
    confirm_payload = {}

    def route_handler(route, request):
        if request.method == 'POST' and '/api/chat/compact' in request.url:
            body = request.post_data_json()
            print("ROUTE_BODY", body)
            # first call (message send)
            if not body.get('confirm'):
                route.fulfill(status=200, body=json.dumps(proposal))
                return
            # second call (confirmation)
            confirm_payload.update(body)
            # reply success
            route.fulfill(status=200, body=json.dumps({'ok': True, 'text': 'done'}))
        else:
            route.continue_()

    page.route('**/api/chat/compact', route_handler)

    # send a message programmatically using exposed ask hook
    page.evaluate("() => window.__test_ask('hello', {isConfirm:false});")

    # confirm dialog should appear (not hidden)
    hidden = page.evaluate("() => window.__isConfirmHidden()")
    assert hidden is False, "confirm gate should be shown"
    # there should be two action buttons in the DOM
    buttons = page.locator('#floating-chat-confirm-actions-list button')
    expect(buttons).to_have_count(2)

    # confirm button should be disabled initially
    expect(page.locator('#floating-chat-confirm-yes')).to_be_disabled()

    # click first action choice
    buttons.nth(0).click()
    expect(page.locator('#floating-chat-confirm-yes')).not_to_be_disabled()

    # click confirm to send the selected action
    page.click('#floating-chat-confirm-yes')

    # allow some time for the intercepted handler to record payload
    time.sleep(0.5)

    assert confirm_payload.get('confirm') is True
    assert confirm_payload.get('pending_id') == 'xyz123'
    assert confirm_payload.get('action_id') == 'act1'
