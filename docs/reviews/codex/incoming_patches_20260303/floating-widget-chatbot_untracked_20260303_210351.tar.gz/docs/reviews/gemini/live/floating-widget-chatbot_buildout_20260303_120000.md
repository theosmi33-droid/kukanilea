# Floating-widget-chatbot Buildout Review — 2026-03-03 12:00:00

**Status:** DOMAIN_OVERLAP_DETECTED on branch `codex/floating-widget-chatbot`

**Betroffene Dateien:**
- `app/static/js/chatbot.js`
- `app/templates/partials/floating_chat.html`

**Shared-Core Edits:** none

**Haupt-Risiken:**
- Confirm-Gate existiert, aber Implementation erlaubt weiterhin unspezifische/"silent" Bestätigungen.
- Frontend sendet bei Bestätigung keinen eindeutigen `action_id`, stattdessen wurde bisher generischer Text gesendet.
- UX kann dazu führen, dass serverseitige schreibende Aktionen ohne explizite Auswahl ausgeführt werden.

**Durchgeführte Änderungen (Domain):**
- Confirm-UI erweitert: Liste vorgeschlagener Aktionen und Auswahl erforderlich.
- Frontend: `pending_actions` + `selectedActionId` eingeführt; Confirm-Button erst aktiv nach Auswahl.
- Payload-Hardening: Confirm-POST enthält nun `pending_id` + `action_id` und keine generische Textausführung.

**Empfohlene Fixes (falls nicht bereits übernommen):**
- Server validiert `pending_id` + `action_id` Paaren vor Ausführung.
- Ergänzende JS-Unit-Tests, Integrationstest: Server sendet proposal, Frontend darf ohne Auswahl nichts ausführen; bestätigten Request prüfen.

**Aufwandsschätzung:** ~1 Arbeitstag für Frontend + Tests.

**Next Steps:**
- Weitere Tests hinzufügen (JS unit + integration). Ich kann Test-Vorschläge liefern.

---
Report erstellt von Worker B.
