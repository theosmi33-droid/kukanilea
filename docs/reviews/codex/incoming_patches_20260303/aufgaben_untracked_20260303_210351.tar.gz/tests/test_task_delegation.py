from __future__ import annotations

import os
import sys

sys.path.append(os.getcwd())

from app.core.logic import task_create, task_delegate, task_list


def test_task_delegate_updates_assignment() -> None:
    tid = task_create(
        tenant="testtenant",
        severity="info",
        task_type="general",
        title="Delegate me",
        details="test",
        created_by="tester",
    )
    assert tid

    ok = task_delegate(str(tid), new_assigned_user="alice", delegated_by="bob")
    assert ok

    tasks = task_list(tenant="testtenant", status="OPEN", limit=10)
    found = [t for t in tasks if str(t.get("id")) == str(tid)]
    assert found
    assert found[0].get("assigned_user") == "alice"
